# MonyGo

**Create • Share • Earn**

MonyGo is a mobile-first starter web app for a creator/reward platform.

## Current MVP
- Mobile-first dark UI
- Create and publish posts
- Community feed
- Like system
- Demo MonyPoints wallet
- Local browser storage
- Responsive layout

## Important
The earning and wallet system in this MVP is **demo-only**. It does not move real money.

For production, add:
1. Secure authentication
2. Backend API + database
3. Server-side reward ledger
4. Anti-abuse/rate limiting
5. Admin moderation
6. Verified payment provider and withdrawal flow
7. Privacy policy, terms, and age/content rules
8. HTTPS and secret management

## Run
Open `index.html` in a browser, or deploy the repository with GitHub Pages.

## GitHub Pages
Repository Settings → Pages → Deploy from branch → `main` → `/ (root)` → Save.
