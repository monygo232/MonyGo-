const KEY="monygo_demo_v1";
const seed=[
  {id:1,title:"Welcome to MonyGo",content:"Create useful content, share it, and earn points. This is the first demo post.",likes:3,liked:false,time:"Just now"}
];
let state=JSON.parse(localStorage.getItem(KEY)||"null")||{balance:0,posts:seed};

const $=id=>document.getElementById(id);
function save(){localStorage.setItem(KEY,JSON.stringify(state));render();}
function render(){
  $("balance").textContent=state.balance;
  $("postCount").textContent=state.posts.length;
  $("likeCount").textContent=state.posts.reduce((n,p)=>n+p.likes,0);
  $("walletBalance").textContent=state.balance;
  const list=$("feedList");
  if(!state.posts.length){list.innerHTML='<div class="empty">No posts yet. Create the first one.</div>';return;}
  list.innerHTML=state.posts.map(p=>`
    <article class="post">
      <div class="post-top">
        <div><h3>${esc(p.title)}</h3><div class="post-meta">${esc(p.time)}</div></div>
        <button class="like ${p.liked?'liked':''}" data-like="${p.id}">♥ ${p.likes}</button>
      </div>
      <p>${esc(p.content)}</p>
      <div class="post-meta">Creator reward: +10 points</div>
    </article>`).join("");
}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}

$("publishBtn").onclick=()=>{
  const title=$("title").value.trim(), content=$("content").value.trim();
  if(!title||!content){$("message").textContent="Please add a title and content.";return;}
  state.posts.unshift({id:Date.now(),title,content,likes:0,liked:false,time:"Just now"});
  state.balance+=10;
  $("title").value="";$("content").value="";
  $("message").textContent="Published! +10 MonyPoints added.";
  save();
};
$("feedList").onclick=e=>{
  const btn=e.target.closest("[data-like]"); if(!btn)return;
  const p=state.posts.find(x=>x.id==btn.dataset.like); if(!p)return;
  p.liked=!p.liked;p.likes+=p.liked?1:-1;save();
};
$("resetBtn").onclick=()=>{if(confirm("Reset the demo data?")){state={balance:0,posts:seed};save();}};
document.querySelectorAll("[data-scroll]").forEach(b=>b.onclick=()=>$(b.dataset.scroll).scrollIntoView({behavior:"smooth"}));
const dlg=$("walletDialog"); $("walletBtn").onclick=()=>dlg.showModal(); $("closeWallet").onclick=()=>dlg.close(); $("closeWallet2").onclick=()=>dlg.close();
render();
